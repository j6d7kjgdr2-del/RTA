import { SERVICES, CANTEEN_MENU } from '../data/campus.js';

const panel = document.getElementById('panel');
const body = document.getElementById('panel-body');
const closeBtn = document.getElementById('panel-close');

let onClose = null;

closeBtn.addEventListener('click', () => hide());

export function onPanelClose(fn) { onClose = fn; }

export function hide() {
  panel.classList.remove('open');
  panel.hidden = true;
  if (onClose) onClose();
}

export function isOpen() { return panel.classList.contains('open'); }

export function show(building) {
  const services = (building.services || [])
    .filter(id => SERVICES[id])
    .map(id => ({ id, ...SERVICES[id] }));
  const isCanteen = services.some(s => s.id === 'canteen-menu');

  let html = `
    <div class="p-kicker">RTA · 校园服务点</div>
    <div class="p-title">${esc(building.name)}</div>
    <div class="p-desc">${esc(building.desc || '')}</div>`;

  if (isCanteen) {
    const menu = CANTEEN_MENU[building.id] || [];
    html += `
      <div class="p-section">
        <h3>11月22日菜品</h3>
        <div class="p-menu">
          ${menu.map(m => `
            <div class="p-menu-row">
              <div><span class="p-menu-name">${esc(m.name)}</span><span class="p-menu-tag">${esc(m.tag)}</span></div>
              ${m.price ? `<div class="p-menu-price">¥${m.price}</div>` : ''}
            </div>`).join('')}
        </div>
        <div class="p-note">${esc(SERVICES['canteen-menu'].note)}</div>
      </div>`;
  }

  if (services.length) {
    html += `<div class="p-section"><h3>可办理服务</h3>`;
    for (const s of services) {
      if (isCanteen && s.id === 'canteen-menu') continue;
      if (s.bookingUrl) {
        html += `<a class="p-link" href="${esc(s.bookingUrl)}" target="_blank" rel="noopener">
          <span>${s.icon} ${esc(s.name)}</span><span class="arrow">›</span></a>`;
      } else {
        html += `<a class="p-link placeholder" href="#" onclick="return false">
          <span>${s.icon} ${esc(s.name)} · 通道待接入</span><span class="arrow">›</span></a>`;
      }
      html += `<div class="p-note">${esc(s.note)}</div>`;
    }
    html += `</div>`;
  }

  body.innerHTML = html;
  open();
}

export function showCat(cat) {
  const stars = '★'.repeat(cat.stars) + '☆'.repeat(5 - cat.stars);
  const alias = cat.alias ? ` · ${esc(cat.alias)}` : '';
  const html = `
    <div class="p-kicker">RTA · 校园猫</div>
    <div class="p-title">${esc(cat.name)}${alias}<span class="cat-status">${esc(cat.status)}</span></div>
    <div class="cat-tags">${cat.tags.map(t => `<span class="cat-tag">${esc(t)}</span>`).join('')}</div>
    <div class="p-section">
      <h3>基础档案</h3>
      <div class="cat-grid">
        ${cat.profile.map(([k, v]) => `
          <div class="cat-cell"><span class="cat-k">${esc(k)}</span><span class="cat-v">${esc(v)}</span></div>`).join('')}
      </div>
    </div>
    <div class="p-section">
      <h3>互动指南<span class="cat-stars">${stars}</span></h3>
      <ul class="cat-tips">${cat.tips.map(t => `<li>${esc(t)}</li>`).join('')}</ul>
    </div>
    <div class="p-section">
      <h3>饮食偏好</h3>
      <ul class="cat-tips">${cat.food.map(t => `<li>${esc(t)}</li>`).join('')}</ul>
    </div>
    <div class="p-note">猫档案由校园猫志愿团队维护。请文明互动：不追赶、不围堵、不随意投喂人食；奶糕、虎皮卷待领养，有意者请联系志愿团队。</div>`;
  body.innerHTML = html;
  open();
}

function open() {
  panel.hidden = false;
  panel.scrollTop = 0;
  // 强制 reflow 以触发过渡，不依赖 rAF（后台标签页 rAF 会暂停）
  void panel.offsetWidth;
  panel.classList.add('open');
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
