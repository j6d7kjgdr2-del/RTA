import * as THREE from 'three';
import { BOUNDS, BUILDINGS, ROADS, WATER, SERVICES } from '../data/campus.js';

const minimap = document.getElementById('minimap');
const mctx = minimap.getContext('2d');
const regionEl = document.getElementById('region-label');
const hoverEl = document.getElementById('hover-label');

const SIZE = 180;
const W = BOUNDS.maxX - BOUNDS.minX;
const D = BOUNDS.maxZ - BOUNDS.minZ;
const scale = SIZE / Math.max(W, D);
const ox = (SIZE - W * scale) / 2;
const oz = (SIZE - D * scale) / 2;

const toMap = (x, z) => [ox + (x - BOUNDS.minX) * scale, oz + (z - BOUNDS.minZ) * scale];

export function drawMinimap(player, cats = []) {
  mctx.clearRect(0, 0, SIZE, SIZE);

  // 底
  mctx.fillStyle = 'rgba(125,154,107,.28)';
  mctx.fillRect(0, 0, SIZE, SIZE);

  // 水系
  mctx.fillStyle = 'rgba(79,127,150,.75)';
  for (const w of WATER) {
    const [mx, mz] = toMap(w.x, w.z);
    mctx.beginPath();
    mctx.ellipse(mx, mz, w.rx * scale, w.rz * scale, 0, 0, Math.PI * 2);
    mctx.fill();
  }

  // 道路
  mctx.fillStyle = 'rgba(200,196,186,.5)';
  for (const r of ROADS) {
    const [mx, mz] = toMap(r.x, r.z);
    mctx.fillRect(mx - r.w * scale / 2, mz - r.d * scale / 2, r.w * scale, r.d * scale);
  }

  // 建筑
  for (const b of BUILDINGS) {
    const [mx, mz] = toMap(b.x, b.z);
    const hasService = (b.services || []).length > 0;
    mctx.fillStyle = hasService ? 'rgba(157,34,53,.95)' : 'rgba(216,211,204,.8)';
    mctx.fillRect(mx - b.w * scale / 2, mz - b.d * scale / 2, Math.max(2, b.w * scale), Math.max(2, b.d * scale));
  }

  // 校园猫（仅本次出现的）
  mctx.fillStyle = '#f2b24a';
  for (const c of cats) {
    const [mx, mz] = toMap(c.x, c.z);
    mctx.beginPath();
    mctx.arc(mx, mz, 2.4, 0, Math.PI * 2);
    mctx.fill();
  }

  // 玩家 + 朝向
  const [px, pz] = toMap(player.pos.x, player.pos.z);
  mctx.save();
  mctx.translate(px, pz);
  mctx.rotate(-player.mesh.rotation.y);
  mctx.fillStyle = 'rgba(255,255,255,.35)';
  mctx.beginPath();
  mctx.moveTo(0, 0);
  mctx.arc(0, 0, 14, -Math.PI / 2 - .5, -Math.PI / 2 + .5);
  mctx.closePath();
  mctx.fill();
  mctx.restore();
  mctx.fillStyle = '#fff';
  mctx.strokeStyle = '#9d2235';
  mctx.lineWidth = 2;
  mctx.beginPath();
  mctx.arc(px, pz, 4, 0, Math.PI * 2);
  mctx.fill();
  mctx.stroke();
}

export function updateRegion(player) {
  const x = player.pos.x, z = player.pos.z;
  let label = '校园绿地';

  const inside = BUILDINGS.find(b =>
    Math.abs(x - b.x) < b.w / 2 + 14 && Math.abs(z - b.z) < b.d / 2 + 14);
  if (inside) {
    label = inside.name;
  } else {
    const road = ROADS.find(r =>
      Math.abs(x - r.x) < r.w / 2 + 2 && Math.abs(z - r.z) < r.d / 2 + 2);
    if (road) label = road.name;
    else {
      const near = BUILDINGS
        .map(b => ({ b, d: Math.hypot(x - b.x, z - b.z) }))
        .sort((a, c) => a.d - c.d)[0];
      if (near && near.d < 120) label = `${near.b.name} 附近`;
    }
  }
  if (regionEl.textContent !== label) regionEl.textContent = label;
}

export function showHover(target, screenX, screenY) {
  const tag = target.kind === 'cat'
    ? '<span class="hl-tag">校园猫</span>'
    : (target.services || []).length
      ? `<span class="hl-tag">${target.services.length} 项服务</span>` : '';
  hoverEl.innerHTML = `${esc(target.name)}${tag}`;
  hoverEl.style.left = screenX + 'px';
  hoverEl.style.top = screenY + 'px';
  hoverEl.hidden = false;
}

export function hideHover() { hoverEl.hidden = true; }

// ---- 就近操作提示 ----
const hintEl = document.getElementById('action-hint');
export function setActionHint(html) {
  if (html === null) { hintEl.hidden = true; return; }
  hintEl.innerHTML = html;
  hintEl.hidden = false;
}

// ---- toast ----
const toastEl = document.getElementById('toast');
let toastTimer = 0;
export function showToast(msg, ms = 2600) {
  toastEl.textContent = msg;
  toastEl.hidden = false;
  requestAnimationFrame(() => toastEl.classList.add('show'));
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toastEl.classList.remove('show');
    setTimeout(() => { toastEl.hidden = true; }, 300);
  }, ms);
}

// ---- 服务点常驻标签（投影到屏幕）----
const labelWrap = document.getElementById('labels');
let labelItems = [];

export function initLabels(cats = []) {
  labelWrap.innerHTML = '';
  labelItems = [];
  for (const b of BUILDINGS.filter(b => (b.services || []).length)) {
    const el = document.createElement('div');
    el.className = 'blabel';
    el.innerHTML = `${esc(b.name)}<span class="blabel-n">${b.services.length}</span>`;
    labelWrap.appendChild(el);
    labelItems.push({ o: b, y: b.h + 8, maxDist: 620, fade: 420, el, v: new THREE.Vector3() });
  }
  // 猫标签：近距才显示，保留「偶遇」感
  for (const c of cats) {
    const el = document.createElement('div');
    el.className = 'blabel cat';
    el.innerHTML = `🐱 ${esc(c.name)}`;
    labelWrap.appendChild(el);
    labelItems.push({ o: c, y: .8, maxDist: 55, fade: 0, el, v: new THREE.Vector3() });
  }
}

export function updateLabels(camera, playerPos) {
  for (const it of labelItems) {
    it.v.set(it.o.x, it.y, it.o.z).project(camera);
    const dist = Math.hypot(playerPos.x - it.o.x, playerPos.z - it.o.z);
    const x = (it.v.x * .5 + .5) * innerWidth;
    const y = (-it.v.y * .5 + .5) * innerHeight;
    const visible = it.v.z < 1 && dist < it.maxDist && x > -60 && x < innerWidth + 60 && y > -40 && y < innerHeight + 40;
    if (!visible) { it.el.style.display = 'none'; continue; }
    it.el.style.display = 'flex';
    it.el.style.left = x + 'px';
    it.el.style.top = y + 'px';
    it.el.style.opacity = it.fade && dist > it.fade ? .45 : 1;
  }
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
