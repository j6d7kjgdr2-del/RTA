// 触屏操控：左下虚拟摇杆（移动）+ 右下鸟瞰按钮，仅触屏设备启用
const ui = document.getElementById('touch-ui');
const stick = document.getElementById('stick');
const knob = document.getElementById('stick-knob');
const btn = document.getElementById('btn-overview');

const R = 46; // 摇杆行程半径（px）

export function initTouch({ onMove, onOverview }) {
  // 仅纯触屏设备启用（pointer: coarse）；触屏笔记本仍走键鼠，?touch=1 可强制开启
  const isTouch = matchMedia('(pointer: coarse)').matches || location.search.includes('touch=1');
  if (!isTouch) return { isTouch: false, setOverviewUI: () => {} };

  document.body.classList.add('touch');
  ui.hidden = false;
  const foot = document.querySelector('.title-foot span');
  if (foot) foot.textContent = '左下摇杆移动 · 拖拽转视角 · 点击建筑使用服务';

  let pid = null, cx = 0, cy = 0;
  const setKnob = (dx, dy) => { knob.style.transform = `translate(${dx}px, ${dy}px)`; };
  const move = e => {
    if (e.pointerId !== pid) return;
    let dx = e.clientX - cx, dy = e.clientY - cy;
    const len = Math.hypot(dx, dy);
    if (len > R) { dx = dx / len * R; dy = dy / len * R; }
    setKnob(dx, dy);
    onMove(dx / R, -dy / R); // x=右, y=前进
  };
  stick.addEventListener('pointerdown', e => {
    pid = e.pointerId;
    try { stick.setPointerCapture(pid); } catch { /* 合成事件无活跃指针 */ }
    const r = stick.getBoundingClientRect();
    cx = r.left + r.width / 2; cy = r.top + r.height / 2;
    move(e);
  });
  stick.addEventListener('pointermove', move);
  const up = e => {
    if (e.pointerId !== pid) return;
    pid = null;
    setKnob(0, 0);
    onMove(0, 0);
  };
  stick.addEventListener('pointerup', up);
  stick.addEventListener('pointercancel', up);

  btn.addEventListener('click', () => onOverview());

  return {
    isTouch: true,
    setOverviewUI(on) {
      btn.textContent = on ? '跟随' : '鸟瞰';
      btn.classList.toggle('on', on);
      stick.style.display = on ? 'none' : '';
      if (on) { pid = null; setKnob(0, 0); onMove(0, 0); }
    },
  };
}
