import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { buildWorld } from './world.js';
import { Player } from './player.js';
import { BOUNDS } from './data/campus.js';
import { drawMinimap, updateRegion, showHover, hideHover, showToast, setActionHint, initLabels, updateLabels } from './ui/hud.js';
import * as panel from './ui/panel.js';
import { initTouch } from './ui/touch.js';

const canvas = document.getElementById('scene');
const titleEl = document.getElementById('title');
const hudEl = document.getElementById('hud');
const loadingEl = document.getElementById('loading');

// ---- 渲染器 ----
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

// ---- 场景 / 天空 ----
const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0xc8e0f4, 400, 2000);

// 渐变天空穹顶
const skyGeo = new THREE.SphereGeometry(1800, 32, 20);
const skyMat = new THREE.ShaderMaterial({
  side: THREE.BackSide,
  depthWrite: false,
  uniforms: {
    uTop: { value: new THREE.Color(0x3a8fd4) },
    uMid: { value: new THREE.Color(0x8ecae6) },
    uBot: { value: new THREE.Color(0xd4eaf7) }
  },
  vertexShader: `
    varying vec3 vWorldPos;
    void main(){
      vec4 wp = modelMatrix * vec4(position,1.0);
      vWorldPos = wp.xyz;
      gl_Position = projectionMatrix * viewMatrix * wp;
    }`,
  fragmentShader: `
    uniform vec3 uTop, uMid, uBot;
    varying vec3 vWorldPos;
    void main(){
      float h = normalize(vWorldPos).y;
      vec3 col = h > 0.0 ? mix(uMid, uTop, h) : mix(uMid, uBot, -h);
      gl_FragColor = vec4(col, 1.0);
    }`
});
scene.add(new THREE.Mesh(skyGeo, skyMat));

// 低多边形云朵：环绕校园外围形成地平线云带（相机始终俯视角色，只有贴近地平线的云可见）
function makeCloud(x, y, z, scale) {
  const g = new THREE.Group();
  const m = new THREE.MeshStandardMaterial({ color: 0xffffff, flatShading: true, roughness: 1, metalness: 0, fog: false });
  const puffs = [
    [0, 0, 0, 1], [-1.4, -.15, .3, .72], [1.5, -.1, -.2, .68],
    [.6, .35, .5, .55], [-.7, .3, -.4, .5]
  ];
  for (const [px, py, pz, s] of puffs) {
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(s * 1.7, 7, 5), m);
    mesh.position.set(px * 3.0, py * 1.6, pz * 3.0);
    mesh.scale.y = .5;
    g.add(mesh);
  }
  g.position.set(x, y, z);
  g.scale.setScalar(scale);
  return g;
}

const clouds = new THREE.Group();
const cloudData = [
  [1400, 180, 0, 18], [1046, 150, 340, 15], [1214, 210, 882, 20],
  [705, 160, 971, 16], [464, 230, 1427, 19], [0, 150, 1100, 15],
  [-433, 200, 1331, 18], [-705, 160, 971, 16], [-1214, 220, 882, 20],
  [-1046, 150, 340, 15], [-1400, 190, 0, 18], [-1046, 160, -340, 15],
  [-1214, 210, -882, 20], [-705, 150, -971, 16], [-464, 230, -1427, 19],
  [0, 160, -1100, 15], [433, 200, -1331, 18], [705, 150, -971, 16],
  [1214, 220, -882, 20], [1046, 160, -340, 15]
];
for (const [cx, cy, cz, cs] of cloudData) clouds.add(makeCloud(cx, cy, cz, cs));
scene.add(clouds);

// ---- 光照 ----
scene.add(new THREE.HemisphereLight(0xdfeaf2, 0x6b7059, 1.05));
const sun = new THREE.DirectionalLight(0xfff2dd, 2.1);
sun.position.set(420, 620, 260);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
const sc = sun.shadow.camera;
sc.left = -700; sc.right = 700; sc.top = 700; sc.bottom = -700;
sc.near = 50; sc.far = 2000;
sun.shadow.bias = -0.0006;
scene.add(sun);

// ---- 世界与玩家 ----
const world = buildWorld(scene);
const player = new Player(scene, canvas, world.colliders);
player.resize(innerWidth, innerHeight);
initLabels(world.cats);

// ---- 鸟瞰模式（固定俯视，拖拽平移） ----
const orbit = new OrbitControls(player.camera, canvas);
orbit.enabled = false;
orbit.enableDamping = true;
orbit.dampingFactor = .12;
orbit.enableRotate = false;          // 禁止旋转
orbit.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
orbit.touches = { ONE: THREE.TOUCH.PAN, TWO: THREE.TOUCH.DOLLY_PAN };
orbit.minDistance = 80;
orbit.maxDistance = 900;
orbit.minPolarAngle = 0;
orbit.maxPolarAngle = 0;             // 锁定完全俯视
let overview = false;
const OVERVIEW_HEIGHT = 380;

// 鸟瞰模式下的拖拽距离追踪（player 禁用时 dragDist 不更新）
let overviewDragDist = 0;
canvas.addEventListener('pointerdown', () => { if (overview) overviewDragDist = 0; });
canvas.addEventListener('pointermove', e => {
  if (overview && e.buttons) overviewDragDist += Math.abs(e.movementX) + Math.abs(e.movementY);
});

function setOverview(on) {
  overview = on;
  orbit.enabled = on;
  player.enabled = !on && started;
  clouds.visible = !on;   // 鸟瞰=地图视图，隐藏云避免遮挡
  for (const c of world.cats) c.icon.visible = on;
  touch.setOverviewUI(on);
  if (on) {
    orbit.target.set(player.pos.x, 0, player.pos.z);
    player.camera.position.set(player.pos.x, OVERVIEW_HEIGHT, player.pos.z);
    player.camera.lookAt(player.pos.x, 0, player.pos.z);
    orbit.update();
  } else {
    // 切回跟随：落到鸟瞰最后指向的位置（点击/平移的中心）
    const spot = freeSpotNear(orbit.target.x, orbit.target.z);
    if (spot) {
      player.pos.set(spot.x, 0, spot.z);
      player.mesh.position.copy(player.pos);
    }
  }
}

// 目标点落在楼里时，向外找最近的空地，避免卡进碰撞体
function freeSpotNear(x, z) {
  x = THREE.MathUtils.clamp(x, BOUNDS.minX + 4, BOUNDS.maxX - 4);
  z = THREE.MathUtils.clamp(z, BOUNDS.minZ + 4, BOUNDS.maxZ - 4);
  if (!player._hits(x, z)) return { x, z };
  for (let r = 3; r <= 48; r += 3) {
    for (let a = 0; a < 8; a++) {
      const nx = x + Math.cos(a * Math.PI / 4) * r;
      const nz = z + Math.sin(a * Math.PI / 4) * r;
      if (!player._hits(nx, nz)) return { x: nx, z: nz };
    }
  }
  return null;
}

const touch = initTouch({
  onMove: (x, y) => { player.stick.x = x; player.stick.y = y; },
  onOverview: () => setOverview(!overview),
});

addEventListener('keydown', e => {
  if (e.code === 'KeyC' && started) setOverview(!overview);
  if (e.code === 'Escape') panel.hide();
});

// ---- 拾取 ----
const ray = new THREE.Raycaster();
const ndc = new THREE.Vector2();
const GROUND_PLANE = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
let hoverBuilding = null;
let nearBuilding = null;

function pick(clientX, clientY) {
  ndc.set((clientX / innerWidth) * 2 - 1, -(clientY / innerHeight) * 2 + 1);
  ray.setFromCamera(ndc, player.camera);
  const hits = ray.intersectObjects(world.pickables, false);
  return hits.length ? { building: world.meta.get(hits[0].object), point: hits[0].point } : null;
}

canvas.addEventListener('pointermove', e => {
  if (!started || e.buttons) { hideHover(); return; }
  const hit = pick(e.clientX, e.clientY);
  if (hit && hit.building) {
    hoverBuilding = hit.building;
    showHover(hit.building, e.clientX, e.clientY);
    canvas.style.cursor = 'pointer';
  } else {
    hoverBuilding = null;
    hideHover();
    canvas.style.cursor = '';
  }
});

canvas.addEventListener('pointerup', e => {
  if (!started) return;
  const dragged = overview ? overviewDragDist > 6 : player.dragDist > 6;
  if (dragged) return;
  const hit = pick(e.clientX, e.clientY);
  if (overview) {
    // 鸟瞰点击=地图点选：把该点记为中心，切回跟随时落地于此
    const gp = hit ? hit.point : ray.ray.intersectPlane(GROUND_PLANE, new THREE.Vector3());
    if (gp) {
      orbit.target.set(gp.x, 0, gp.z);
      orbit.update();
    }
    if (hit && hit.building) tryOpen(hit.building);
    return;
  }
  if (hit && hit.building) tryOpen(hit.building);
});

// 「走到对应区域才能使用服务」是本项目核心交互：
// 跟随视角下需走近建筑；鸟瞰视角等同地图点选，不受距离限制
const SERVICE_RADIUS = 55;
const CAT_RADIUS = 12;

function distToBuilding(b) {
  const dx = Math.max(Math.abs(player.pos.x - b.x) - b.w / 2, 0);
  const dz = Math.max(Math.abs(player.pos.z - b.z) - b.d / 2, 0);
  return Math.hypot(dx, dz);
}

function hasService(b) { return (b.services || []).length > 0; }

function tryOpen(b) {
  // 猫档案不受距离限制：点得到就能看（猫本体小，远处几乎点不中）
  if (b.kind === 'cat') { panel.showCat(b); return; }
  if (overview || !hasService(b)) { panel.show(b); return; }
  const d = distToBuilding(b);
  if (d <= SERVICE_RADIUS) panel.show(b);
  else showToast(`走近 ${b.name} 才能使用服务（还有约 ${Math.round(d - SERVICE_RADIUS)} m）`);
}

function nearestInteractable() {
  let best = null, bestD = Infinity;
  for (const b of world.meta.values()) {
    const radius = b.kind === 'cat' ? CAT_RADIUS : SERVICE_RADIUS;
    if (b.kind !== 'cat' && !hasService(b)) continue;
    const d = distToBuilding(b);
    if (d < radius && d < bestD) { bestD = d; best = b; }
  }
  return best;
}

addEventListener('keydown', e => {
  if (e.code === 'KeyE' && started && !overview && nearBuilding) {
    if (nearBuilding.kind === 'cat') panel.showCat(nearBuilding);
    else panel.show(nearBuilding);
  }
});

panel.onPanelClose(() => { /* 预留：关闭面板时的副作用 */ });

// ---- 启动 ----
let started = false;
document.getElementById('start').addEventListener('click', () => {
  started = true;
  player.enabled = true;
  titleEl.classList.add('gone');
  hudEl.hidden = false;
  loadingEl.classList.add('gone');
});

// ---- 主循环 ----
const clock = new THREE.Clock();
let frame = 0;

renderer.setAnimationLoop(() => {
  const dt = Math.min(clock.getDelta(), .05);

  // 云带缓慢旋转漂移
  clouds.rotation.y += dt * 0.004;

  // 校园猫_idle 动画（摆尾 / 动耳 / 靠近时转头看玩家）
  const t = clock.elapsedTime;
  for (const c of world.cats) c.update(t, player.pos);

  if (started) {
    if (overview) orbit.update();
    else player.update(dt);

    frame++;
    if (frame % 2 === 0) {
      drawMinimap(player, world.cats);
      updateRegion(player);
      updateLabels(player.camera, player.pos);
      if (!overview) {
        const nb = nearestInteractable();
        if (nb !== nearBuilding) {
          nearBuilding = nb;
          setActionHint(nb ? (nb.kind === 'cat'
            ? `<b>E</b> / 点击小猫 · 查看「${nb.name}」档案`
            : `<b>E</b> / 点击建筑 · 打开「${nb.name}」`) : null);
        }
      } else if (nearBuilding) {
        nearBuilding = null;
        setActionHint(null);
      }
    }
  }

  renderer.render(scene, player.camera);
});

// ---- 自适应 ----
addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight);
  player.resize(innerWidth, innerHeight);
});

loadingEl.classList.add('gone');
