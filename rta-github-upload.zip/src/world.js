import * as THREE from 'three';
import { BOUNDS, PALETTE, BUILDINGS, ROADS, WATER, PLAZAS, GATES } from './data/campus.js';
import { CATS, CAT_SPOTS } from './data/cats.js';

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const mat = (color, opts = {}) =>
  new THREE.MeshStandardMaterial({ color, flatShading: true, roughness: .92, metalness: 0, ...opts });

// 程序化立面贴图：人大红砖 + 窗格 + 混凝土基座，避免建筑读作纯色方块
function facadeTexture(baseHex) {
  const c = document.createElement('canvas');
  c.width = 128; c.height = 128;
  const g = c.getContext('2d');
  const base = '#' + baseHex.toString(16).padStart(6, '0');
  g.fillStyle = base;
  g.fillRect(0, 0, 128, 128);

  // 砖缝噪点
  g.fillStyle = 'rgba(0,0,0,.06)';
  for (let y = 0; y < 128; y += 8) g.fillRect(0, y, 128, 1);

  // 窗格：4 列 3 行
  for (let iy = 0; iy < 3; iy++) {
    for (let ix = 0; ix < 4; ix++) {
      const x = 8 + ix * 30, y = 14 + iy * 34;
      g.fillStyle = 'rgba(216,211,204,.9)';          // 混凝土窗框
      g.fillRect(x - 2, y - 2, 20, 20);
      g.fillStyle = 'rgba(38,52,66,.92)';            // 玻璃
      g.fillRect(x, y, 16, 16);
      g.fillStyle = 'rgba(150,190,210,.35)';         // 反光
      g.fillRect(x, y, 16, 5);
    }
  }

  // 底部混凝土基座带
  g.fillStyle = 'rgba(216,211,204,.95)';
  g.fillRect(0, 116, 128, 12);

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function facadeMaterial(baseHex, w, h) {
  const tex = facadeTexture(baseHex);
  // 约每 8m 一扇窗、每 4m 一层，避免窗格过密读成筒子楼
  tex.repeat.set(Math.max(1, Math.round(w / 32)), Math.max(1, Math.round(h / 12)));
  return new THREE.MeshStandardMaterial({ map: tex, roughness: .9, metalness: 0 });
}

// 门牌：人大红底 + 白色门名
function gateSignMaterial(name) {
  const c = document.createElement('canvas');
  c.width = 512; c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = '#9d2235';
  g.fillRect(0, 0, 512, 128);
  g.fillStyle = '#fff';
  g.font = 'bold 62px "PingFang SC", "Microsoft YaHei", sans-serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(name, 256, 70);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return new THREE.MeshBasicMaterial({ map: tex });
}

// 地标标语：红底黄字双面雕塑墙贴图
function sloganMaterial() {
  const c = document.createElement('canvas');
  c.width = 1024; c.height = 340;
  const g = c.getContext('2d');
  g.fillStyle = '#c8202f';
  g.fillRect(0, 0, 1024, 340);
  g.fillStyle = '#f4d03f';
  g.font = 'bold 92px "PingFang SC", "Microsoft YaHei", sans-serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText('党办的大学让党放心', 512, 100);
  g.fillText('人民的大学不负人民', 512, 240);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return new THREE.MeshBasicMaterial({ map: tex });
}

// 鸟瞰模式下的猫图标（真实比例太小，用图标标出）
function catIconTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = 'rgba(23,25,29,.85)';
  g.beginPath(); g.arc(64, 64, 58, 0, Math.PI * 2); g.fill();
  g.strokeStyle = '#f2b24a'; g.lineWidth = 6; g.stroke();
  g.fillStyle = '#f2b24a';
  g.beginPath(); g.moveTo(40, 54); g.lineTo(46, 26); g.lineTo(60, 44); g.closePath(); g.fill();
  g.beginPath(); g.moveTo(88, 54); g.lineTo(82, 26); g.lineTo(68, 44); g.closePath(); g.fill();
  g.beginPath(); g.arc(64, 68, 32, 0, Math.PI * 2); g.fill();
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function buildWorld(scene) {
  const group = new THREE.Group();
  const pickables = [];
  const meta = new Map();      // mesh -> building data
  const colliders = [];        // AABB 供玩家碰撞

  const W = BOUNDS.maxX - BOUNDS.minX;
  const D = BOUNDS.maxZ - BOUNDS.minZ;
  const cx = (BOUNDS.minX + BOUNDS.maxX) / 2;
  const cz = (BOUNDS.minZ + BOUNDS.maxZ) / 2;

  // ---- 地面 ----
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(W + 400, D + 400),
    mat(PALETTE.grass, { roughness: 1 })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.set(cx, 0, cz);
  ground.receiveShadow = true;
  group.add(ground);

  // ---- 广场 ----
  for (const p of PLAZAS) {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(p.w, p.d), mat(PALETTE.plaza));
    m.rotation.x = -Math.PI / 2;
    m.position.set(p.x, .05, p.z);
    m.receiveShadow = true;
    group.add(m);
  }

  // ---- 道路 ----
  for (const r of ROADS) {
    const road = new THREE.Mesh(new THREE.PlaneGeometry(r.w, r.d), mat(PALETTE.road));
    road.rotation.x = -Math.PI / 2;
    road.position.set(r.x, .06, r.z);
    road.receiveShadow = true;
    group.add(road);
    // 中线
    const lineW = r.w > r.d ? r.w * .92 : .5;
    const lineD = r.w > r.d ? .5 : r.d * .92;
    const line = new THREE.Mesh(new THREE.PlaneGeometry(lineW, lineD), mat(PALETTE.roadLine));
    line.rotation.x = -Math.PI / 2;
    line.position.set(r.x, .1, r.z);
    group.add(line);
  }

  // ---- 水系 ----
  for (const w of WATER) {
    const lake = new THREE.Mesh(
      new THREE.CircleGeometry(1, 40),
      new THREE.MeshStandardMaterial({
        color: PALETTE.water, roughness: .25, metalness: .1,
        transparent: true, opacity: .9, flatShading: true,
      })
    );
    lake.rotation.x = -Math.PI / 2;
    lake.scale.set(w.rx, w.rz, 1);
    lake.position.set(w.x, .03, w.z);
    group.add(lake);
  }

  // ---- 建筑 ----
  const concrete = mat(PALETTE.concrete);
  const roofMat = mat(PALETTE.roof);

  for (const b of BUILDINGS) {
    const g = new THREE.Group();
    g.position.set(b.x, 0, b.z);

    if (b.kind === 'flat') {
      // 田径场：跑道 + 内场
      const track = new THREE.Mesh(new THREE.PlaneGeometry(b.w, b.d), mat(0xa8503f));
      track.rotation.x = -Math.PI / 2; track.position.y = .05; track.receiveShadow = true;
      const field = new THREE.Mesh(new THREE.PlaneGeometry(b.w * .62, b.d * .55), mat(0x5f8a4e));
      field.rotation.x = -Math.PI / 2; field.position.y = .09; field.receiveShadow = true;
      g.add(track, field);
    } else if (b.kind === 'court') {
      // 露天球场群：塑胶底 + 绿色场芯
      const base = new THREE.Mesh(new THREE.PlaneGeometry(b.w, b.d), mat(0xb8654a));
      base.rotation.x = -Math.PI / 2; base.position.y = .05; base.receiveShadow = true;
      const core = new THREE.Mesh(new THREE.PlaneGeometry(b.w * .82, b.d * .82), mat(0x5f8a4e));
      core.rotation.x = -Math.PI / 2; core.position.y = .09; core.receiveShadow = true;
      g.add(base, core);
    } else {
      const body = new THREE.Mesh(
        new THREE.BoxGeometry(b.w, b.h, b.d),
        facadeMaterial(b.kind === 'dorm' ? PALETTE.brickLight : PALETTE.brick, b.w, b.h)
      );
      body.position.y = b.h / 2;
      body.castShadow = true; body.receiveShadow = true;
      g.add(body);

      // 混凝土基座带（呼应全校区统一设计语言）
      const base = new THREE.Mesh(new THREE.BoxGeometry(b.w + 2.4, 3, b.d + 2.4), concrete);
      base.position.y = 1.5; base.receiveShadow = true;
      g.add(base);

      // 屋顶
      const roof = new THREE.Mesh(new THREE.BoxGeometry(b.w * .88, 1.6, b.d * .88), roofMat);
      roof.position.y = b.h + .8; roof.castShadow = true;
      g.add(roof);

      if (b.kind === 'landmark') {
        // 地标加一个玻璃顶冠
        const crown = new THREE.Mesh(
          new THREE.BoxGeometry(b.w * .5, b.h * .28, b.d * .5),
          new THREE.MeshStandardMaterial({
            color: 0x9fc4d4, roughness: .15, metalness: .35,
            transparent: true, opacity: .75, flatShading: true,
          })
        );
        crown.position.y = b.h + b.h * .14 + 1.6;
        crown.castShadow = true;
        g.add(crown);
      }

      if (b.kind === 'dorm') {
        // 宿舍竖向混凝土分隔带
        const fins = Math.max(3, Math.round(b.w / 16));
        for (let i = 0; i <= fins; i++) {
          const fx = -b.w / 2 + (b.w / fins) * i;
          const fin = new THREE.Mesh(new THREE.BoxGeometry(1.2, b.h, b.d + .6), concrete);
          fin.position.set(fx, b.h / 2, 0);
          g.add(fin);
        }
      }

      colliders.push({
        minX: b.x - b.w / 2, maxX: b.x + b.w / 2,
        minZ: b.z - b.d / 2, maxZ: b.z + b.d / 2,
      });
    }

    // 整组可点：给 body 挂引用
    g.traverse(o => { if (o.isMesh) { pickables.push(o); meta.set(o, b); } });
    group.add(g);
  }

  // ---- 校门：双柱 + 人大红横梁 + 朝外门牌 ----
  for (const gt of GATES) {
    const g = new THREE.Group();
    g.position.set(gt.x, 0, gt.z);
    const off = 11;                       // 柱中心距路中线
    const span = off * 2 + 3;
    const pillarGeo = new THREE.BoxGeometry(1.6, 7, 1.6);
    const baseGeo = new THREE.BoxGeometry(2.6, 1, 2.6);
    const beamGeo = gt.axis === 'x'
      ? new THREE.BoxGeometry(2, 1.7, span)
      : new THREE.BoxGeometry(span, 1.7, 2);
    const brick = mat(PALETTE.brick);
    const p1 = new THREE.Mesh(pillarGeo, brick);
    const p2 = new THREE.Mesh(pillarGeo, brick);
    const b1 = new THREE.Mesh(baseGeo, concrete);
    const b2 = new THREE.Mesh(baseGeo, concrete);
    if (gt.axis === 'x') {
      p1.position.set(0, 3.5, -off); p2.position.set(0, 3.5, off);
      b1.position.set(0, .5, -off); b2.position.set(0, .5, off);
    } else {
      p1.position.set(-off, 3.5, 0); p2.position.set(off, 3.5, 0);
      b1.position.set(-off, .5, 0); b2.position.set(off, .5, 0);
    }
    p1.castShadow = p2.castShadow = true;
    const beam = new THREE.Mesh(beamGeo, brick);
    beam.position.y = 7.6; beam.castShadow = true;

    const board = new THREE.Mesh(new THREE.PlaneGeometry(10.5, 2.5), gateSignMaterial(gt.name));
    board.position.y = 7.6;
    if (gt.face === 'w') { board.rotation.y = -Math.PI / 2; board.position.x = -1.05; }
    else { board.position.z = 1.05; }

    g.add(p1, p2, b1, b2, beam, board);
    group.add(g);

    // 门柱碰撞
    for (const s of [-off, off]) {
      colliders.push(gt.axis === 'x'
        ? { minX: gt.x - .8, maxX: gt.x + .8, minZ: gt.z + s - .8, maxZ: gt.z + s + .8 }
        : { minX: gt.x + s - .8, maxX: gt.x + s + .8, minZ: gt.z - .8, maxZ: gt.z + .8 });
    }
  }

  // ---- 地标标语雕塑：凤栖三路×明德街路口东南角，面向西 ----
  {
    const g = new THREE.Group();
    g.position.set(-310, 0, 165);
    const red = mat(0xc8202f);
    const wall = new THREE.Mesh(new THREE.BoxGeometry(1.6, 5.2, 16), red);
    wall.position.y = 2.6; wall.castShadow = true;
    // 起伏墙顶（两段弧）
    const humpGeo = new THREE.SphereGeometry(4, 10, 6);
    const h1 = new THREE.Mesh(humpGeo, red);
    h1.position.set(0, 5, -3.5); h1.scale.set(.2, .55, 1); h1.castShadow = true;
    const h2 = new THREE.Mesh(humpGeo, red);
    h2.position.set(0, 4.7, 4); h2.scale.set(.2, .5, .9); h2.castShadow = true;
    // 西侧花坛：白围栏 + 粉/黄两层花带
    const planter = new THREE.Mesh(new THREE.BoxGeometry(5, .8, 20), mat(0xf2efe8));
    planter.position.set(-3, .4, 0); planter.receiveShadow = true;
    const flower1 = new THREE.Mesh(new THREE.BoxGeometry(4.6, .3, 19.6), mat(0xd4437e));
    flower1.position.set(-3, .95, 0);
    const flower2 = new THREE.Mesh(new THREE.BoxGeometry(4.6, .3, 10), mat(0xe8c547));
    flower2.position.set(-3, 1.15, -4);
    // 标语字面朝西
    const board = new THREE.Mesh(new THREE.PlaneGeometry(15, 5), sloganMaterial());
    board.rotation.y = -Math.PI / 2;
    board.position.set(-.85, 2.7, 0);
    g.add(wall, h1, h2, planter, flower1, flower2, board);
    group.add(g);
    colliders.push({ minX: -311.2, maxX: -308.8, minZ: 157, maxZ: 173 });
  }

  // ---- 树木（种子随机，稳定）----
  const rnd = mulberry32(20261121);
  const trunkGeo = new THREE.CylinderGeometry(.5, .8, 4, 6);
  const leafGeo = new THREE.IcosahedronGeometry(4.2, 0);
  const trunkMat = mat(0x6b4a33);
  const leafMats = [mat(PALETTE.tree), mat(PALETTE.treeDark)];

  const inBuilding = (x, z, pad = 6) =>
    colliders.some(c => x > c.minX - pad && x < c.maxX + pad && z > c.minZ - pad && z < c.maxZ + pad);

  let placed = 0, tries = 0;
  while (placed < 220 && tries < 3000) {
    tries++;
    const x = BOUNDS.minX + rnd() * W;
    const z = BOUNDS.minZ + rnd() * D;
    if (inBuilding(x, z, 8)) continue;
    // 避开道路
    if (ROADS.some(r =>
      Math.abs(x - r.x) < r.w / 2 + 3 && Math.abs(z - r.z) < r.d / 2 + 3)) continue;

    const tree = new THREE.Group();
    const s = .7 + rnd() * .8;
    const trunk = new THREE.Mesh(trunkGeo, trunkMat);
    trunk.position.y = 2; trunk.castShadow = true;
    const leaf = new THREE.Mesh(leafGeo, leafMats[rnd() > .5 ? 1 : 0]);
    leaf.position.y = 5.4; leaf.scale.setScalar(s); leaf.castShadow = true;
    tree.add(trunk, leaf);
    tree.position.set(x, 0, z);
    tree.rotation.y = rnd() * Math.PI;
    group.add(tree);
    placed++;
  }

  // ---- 校园猫 ----
  const cats = buildCats(group, colliders, pickables, meta);

  scene.add(group);
  return { pickables, meta, colliders, cats };
}

// ---- 校园猫：坐姿低多边形猫，面朝 +Z ----
function makeCatMesh(cat) {
  const c = cat.colors;
  const g = new THREE.Group();

  const hips = new THREE.Mesh(new THREE.SphereGeometry(.16, 8, 6), mat(c.body));
  hips.position.y = .15; hips.scale.set(1, .95, 1.18); hips.castShadow = true;
  const chest = new THREE.Mesh(new THREE.SphereGeometry(.115, 8, 6), mat(c.chest));
  chest.position.set(0, .3, -.02); chest.scale.set(.92, 1.35, .92); chest.castShadow = true;

  const headPivot = new THREE.Group();
  headPivot.position.set(0, .46, -.02);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.105, 10, 8), mat(c.head));
  head.castShadow = true;
  const earGeo = new THREE.ConeGeometry(.05, .1, 4);
  const earL = new THREE.Mesh(earGeo, mat(c.ears)); earL.position.set(-.055, .09, 0); earL.rotation.z = .18;
  const earR = new THREE.Mesh(earGeo, mat(c.ears)); earR.position.set(.055, .09, 0); earR.rotation.z = -.18;
  const eyeGeo = new THREE.SphereGeometry(.014, 6, 5);
  const eyeMat = mat(0x1a1a1a);
  const eyeL = new THREE.Mesh(eyeGeo, eyeMat); eyeL.position.set(-.04, .015, .09);
  const eyeR = new THREE.Mesh(eyeGeo, eyeMat); eyeR.position.set(.04, .015, .09);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(.012, 5, 4), mat(0xd98a94));
  nose.position.set(0, -.012, .1);
  headPivot.add(head, earL, earR, eyeL, eyeR, nose);
  if (c.patch) {
    const patch = new THREE.Mesh(new THREE.SphereGeometry(.05, 6, 5), mat(c.patch.c));
    patch.position.set(...c.patch.p);
    patch.scale.set(...c.patch.s);
    headPivot.add(patch);
  }

  // 尾巴：盘在身前的圆弧，整体可左右扫动
  const tailPivot = new THREE.Group();
  tailPivot.position.set(0, .045, .04);
  const tail = new THREE.Mesh(
    new THREE.TorusGeometry(.19, cat.fluffy ? .034 : .024, 6, 14, Math.PI * .9),
    mat(c.tail)
  );
  tail.rotation.x = Math.PI / 2;
  tail.castShadow = true;
  const tip = new THREE.Mesh(new THREE.SphereGeometry(cat.fluffy ? .04 : .03, 6, 5), mat(c.tail));
  const a = Math.PI * .9;
  tip.position.set(Math.cos(a) * .19, Math.sin(a) * .19, 0);
  tail.add(tip);
  tailPivot.add(tail);

  g.add(hips, chest, headPivot, tailPivot);
  g.scale.setScalar(cat.scale || 1);
  return { group: g, headPivot, tailPivot, earL, earR };
}

function buildCats(group, colliders, pickables, meta) {
  const forceAll = location.search.includes('cats=all');
  const spots = CAT_SPOTS.slice();
  for (let i = spots.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [spots[i], spots[j]] = [spots[j], spots[i]];
  }

  const cats = [];
  let si = 0;
  const iconTex = catIconTexture();
  for (const data of CATS) {
    // 彩蛋猫每次进校园约 55% 概率出现；?cats=all 强制全出现（演示用）
    if (!data.fixed && !forceAll && Math.random() >= .55) continue;
    const spot = data.fixed ? data : spots[si++ % spots.length];

    const rig = makeCatMesh(data);
    rig.group.position.set(spot.x, 0, spot.z);
    rig.group.rotation.y = Math.random() * Math.PI * 2;
    group.add(rig.group);

    // 隐形拾取代理：猫本体太小，远处也能点中
    const proxy = new THREE.Mesh(
      new THREE.CylinderGeometry(.5, .5, .9, 8),
      new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, depthWrite: false })
    );
    proxy.position.y = .45;
    rig.group.add(proxy);

    // 鸟瞰图标：380m 高度下真实比例只有几个像素，用悬浮标记标出
    const icon = new THREE.Sprite(new THREE.SpriteMaterial({ map: iconTex, transparent: true, depthTest: false }));
    icon.position.set(spot.x, 2, spot.z);
    icon.scale.setScalar(16);
    icon.renderOrder = 10;
    icon.visible = false;
    group.add(icon);

    const cat = {
      ...data, kind: 'cat', x: spot.x, z: spot.z, w: .6, d: .6,
      group: rig.group, icon, phase: Math.random() * 10,
      update(t, p) {
        rig.tailPivot.rotation.y = Math.sin(t * 1.5 + this.phase) * .25;
        rig.earL.rotation.z = .18 + Math.sin(t * 2.1 + this.phase) * .05;
        rig.earR.rotation.z = -.18 - Math.sin(t * 1.7 + this.phase + 2) * .05;
        // 玩家靠近时转头看向玩家
        let want = 0;
        const d = Math.hypot(p.x - this.x, p.z - this.z);
        if (d < 12) {
          want = Math.atan2(p.x - this.x, p.z - this.z) - this.group.rotation.y;
          while (want > Math.PI) want -= Math.PI * 2;
          while (want < -Math.PI) want += Math.PI * 2;
          want = THREE.MathUtils.clamp(want, -1.2, 1.2);
        }
        rig.headPivot.rotation.y += (want - rig.headPivot.rotation.y) * .08;
      },
    };
    meta.set(proxy, cat);
    pickables.push(proxy);
    colliders.push({ minX: spot.x - .2, maxX: spot.x + .2, minZ: spot.z - .2, maxZ: spot.z + .2 });
    cats.push(cat);
  }
  return cats;
}
