// 校园空间数据（单位：米，1 单位 = 1 米）
// 坐标约定：x 轴向东为正，z 轴向南为正（north = -z）
//
// 布局依据 2026-11-21 实测高德坐标（GCJ-02，48 个建筑中心点）线性投影：
// 原点 lng0=116.745658, lat0=39.906425；x=(lng-lng0)*85394, z=(lat0-lat)*111320。
// 建筑占地尺寸按高德矢量图楼块轮廓估测；图书馆在建未收录，石墨书房为临时阅览替代。

export const BOUNDS = { minX: -620, maxX: 580, minZ: -450, maxZ: 440 };

// 人大红 + 混凝土，全校区统一设计语言
export const PALETTE = {
  brick: 0x9d2235,
  brickLight: 0xb03a4b,
  concrete: 0xd8d3cc,
  roof: 0x6e6a64,
  grass: 0x7d9a6b,
  road: 0x4a4d52,
  roadLine: 0xc9c4ba,
  water: 0x4f7f96,
  tree: 0x4e7042,
  treeDark: 0x3d5a34,
  plaza: 0xcfc9bf,
};

// kind: block 普通楼 / dorm 宿舍 / landmark 地标 / flat 运动场 / court 球场 / pod 地下服务点
export const BUILDINGS = [
  // ---- 西区 ----
  { id: 'west-track', name: '西运动场', en: 'West Playgrounds', kind: 'flat', x: -428, z: -205, w: 80, d: 140, h: 1,
    desc: '西区田径场。', services: [] },
  { id: 'courts', name: '排球场及篮球场', en: 'Volleyball & Basketball Courts', kind: 'court', x: -438, z: -376, w: 120, d: 100, h: 1,
    desc: '西北区露天球场群。', services: [] },
  { id: 'jd', name: '京东群学楼', en: 'Jingdong Hall', kind: 'block', x: -530, z: 197, w: 100, d: 60, h: 24,
    desc: '校友刘强东捐资冠名。楼内设19间智慧教室，以及社会学院、人口与健康学院办公场地；瑞幸咖啡位于楼内。', services: ['quiet-pod'] },
  { id: 'ye', name: '叶澄海楼', en: 'Ye Chenghai Building', kind: 'block', x: -462, z: 12, w: 65, d: 60, h: 24,
    desc: '校友叶澄海捐资冠名，设计源自“三棱镜”。楼内设12间智慧教室，以及国际关系学院、新闻学院办公场地。', services: ['quiet-pod'] },
  { id: 'art', name: '艺术楼', en: 'Art Building', kind: 'block', x: -398, z: 61, w: 60, d: 45, h: 22,
    desc: '设计源自“自由的艺术盒子”。楼内设智慧教室、专业教室、“悦音工坊”，以及艺术学院办公场地。', services: [] },
  { id: 'future-comm', name: '未来传播中心', en: 'Future Communication Center', kind: 'block', x: -395, z: -3, w: 40, d: 40, h: 24,
    desc: '传播学院组团；2026-2027学年秋季学期暂不投用。', services: [] },
  { id: 'sw1', name: '西南学部楼 · 1号楼', en: 'Southwest Building for Schools 1', kind: 'block', x: -419, z: 175, w: 90, d: 46, h: 26,
    desc: '楼内设27间智慧教室，以及马克思主义学院、中共党史党建学院、法学院办公场地。', services: [] },
  { id: 'sw2', name: '西南学部楼 · 2号楼', en: 'Southwest Building for Schools 2', kind: 'block', x: -426, z: 220, w: 95, d: 36, h: 26,
    desc: '楼内设27间智慧教室，以及马克思主义学院、中共党史党建学院、法学院办公场地。', services: [] },

  // ---- 中西部组团（明德街以北）----
  { id: 'heyuan', name: '禾园食堂', en: 'Heyuan Dining Hall', kind: 'block', x: -304, z: 35, w: 46, d: 40, h: 16,
    desc: '西区主食堂，走到门口就能看今天吃什么。G层为风味餐厅并设水吧，1层设基本大伙、民族餐厅与咖啡店，2层引进麦当劳等餐饮。', services: ['canteen-menu'] },
  { id: 'gx1', name: '公学一楼', en: 'Teaching Building 1', kind: 'block', x: -238, z: 33, w: 72, d: 40, h: 26,
    desc: '以“陕北公学”命名的公共教学楼。设27间智慧教室，含230人教室3间、400人教室1间。', services: ['activity-space', 'quiet-pod'] },
  { id: 'fin', name: '财金楼', en: 'Finance Building', kind: 'block', x: -181, z: 37, w: 30, d: 38, h: 24,
    desc: '楼内设10间智慧教室，以及财政金融学院、国际金融学院办公场地。', services: [] },
  { id: 'econ', name: '经济学部楼', en: 'Economics Building', kind: 'block', x: -285, z: 102, w: 70, d: 42, h: 26,
    desc: '楼内设28间智慧教室，以及劳动人事学院、经济学院、应用经济学院、和平与发展学院、统计学院办公场地。', services: ['quiet-pod'] },
  { id: 'biz', name: '商学楼', en: 'Business Building', kind: 'block', x: -192, z: 98, w: 50, d: 40, h: 24,
    desc: '楼内设29间智慧教室，以及商学院、统计与大数据研究院办公场地。', services: ['quiet-pod'] },
  { id: 'shaogong', name: '陕公堂', en: 'Shangong Hall', kind: 'block', x: -150, z: -17, w: 45, d: 35, h: 20,
    desc: '报告厅与集会场所。', services: [] },

  // ---- 求实公寓组团 ----
  { id: 'qiushi1', name: '求实公寓 1号楼', en: 'Qiushi Residence Hall 1', kind: 'dorm', x: -308, z: -145, w: 40, d: 26, h: 32,
    desc: '留学生公寓。求实公寓共4栋，均为地上6层。', services: [] },
  { id: 'qiushi2', name: '求实公寓 2号楼', en: 'Qiushi Residence Hall 2', kind: 'dorm', x: -282, z: -183, w: 40, d: 26, h: 32,
    desc: '硕士男生楼。求实公寓共4栋，均为地上6层。', services: [] },
  { id: 'qiushi3', name: '求实公寓 3号楼', en: 'Qiushi Residence Hall 3', kind: 'dorm', x: -277, z: -233, w: 40, d: 26, h: 32,
    desc: '硕士女生楼。求实公寓共4栋，均为地上6层。', services: [] },
  { id: 'qiushi4', name: '求实公寓 4号楼', en: 'Qiushi Residence Hall 4', kind: 'dorm', x: -275, z: -284, w: 40, d: 26, h: 32,
    desc: '硕士女生楼。求实公寓共4栋，均为地上6层。', services: [] },
  { id: 'community', name: '求实学习中心（社区成长空间）', en: 'Qiushi Learning Center', kind: 'block', x: -246, z: -250, w: 20, d: 14, h: 8,
    desc: '位于求实公寓花园层（G层），即求实学习中心；布设党建活动、研学阅读、咨询辅导、团体活动、运动健身、美育文化空间及安全训练馆。', services: ['study-room', 'quiet-pod'] },
  { id: 'haolinju', name: '好邻居超市', en: 'Haolinju Supermarket', kind: 'block', x: -238, z: -286, w: 20, d: 14, h: 6,
    desc: '公寓区校园超市。', services: [] },
  { id: 'jd-express', name: '京东快递驿站', en: 'JD Express Station', kind: 'block', x: -366, z: -367, w: 25, d: 15, h: 6,
    desc: '快递收发点。', services: [] },

  // ---- 北区：远见公寓围合组团（宝塔山路以北）----
  { id: 'yuanjian1', name: '远见公寓 1号楼', en: 'Yuanjian Residence Hall 1', kind: 'dorm', x: -278, z: -332, w: 45, d: 46, h: 32,
    desc: '硕士女生楼。远见公寓均为中国学生公寓，G层配有健身房、超市、文印、洗衣等业态。', services: [] },
  { id: 'yuanjian2', name: '远见公寓 2号楼', en: 'Yuanjian Residence Hall 2', kind: 'dorm', x: -260, z: -401, w: 45, d: 46, h: 32,
    desc: '硕士男生楼。远见公寓均为中国学生公寓，G层配有健身房、超市、文印、洗衣等业态。', services: [] },
  { id: 'learning', name: '远见学习中心', en: 'Yuanjian Learning Center', kind: 'block', x: -189, z: -399, w: 40, d: 24, h: 20,
    desc: '位于远见2楼与3楼中间，共4层：1层多功能报告厅，2层“一站式”学生社区服务大厅，3、4层研学空间，设研学工位与万得、彭博、中指数据库终端。', services: ['study-room', 'quiet-pod'] },
  { id: 'yuanjian3', name: '远见公寓 3号楼', en: 'Yuanjian Residence Hall 3', kind: 'dorm', x: -150, z: -400, w: 40, d: 24, h: 32,
    desc: '硕士女生楼。远见公寓均为中国学生公寓，G层配有健身房、超市、文印、洗衣等业态。', services: [] },
  { id: 'gym', name: '健身房（远见公寓G层）', en: 'Gym (Yuanjian Halls G Floor)', kind: 'pod', x: -118, z: -395, w: 20, d: 16, h: 4,
    desc: '位于远见公寓组团花园层（G层）；同层还有超市、饮品店、水果店、文印店、洗衣店、通信营业厅等。', services: ['gym'] },
  { id: 'yuanjian4', name: '远见公寓 4号楼', en: 'Yuanjian Residence Hall 4', kind: 'dorm', x: -79, z: -397, w: 45, d: 46, h: 32,
    desc: '本硕男生楼。远见公寓均为中国学生公寓，G层配有健身房、超市、文印、洗衣等业态。', services: [] },
  { id: 'yuanjian5', name: '远见公寓 5号楼', en: 'Yuanjian Residence Hall 5', kind: 'dorm', x: -79, z: -331, w: 45, d: 46, h: 32,
    desc: '本科女生楼。远见公寓均为中国学生公寓，G层配有健身房、超市、文印、洗衣等业态。', services: [] },
  { id: 'yuanjian6', name: '远见公寓 6号楼', en: 'Yuanjian Residence Hall 6', kind: 'dorm', x: -148, z: -332, w: 60, d: 24, h: 32,
    desc: '本硕女生楼。远见公寓均为中国学生公寓，G层配有健身房、超市、文印、洗衣等业态。', services: [] },
  { id: 'fengyuan', name: '丰园食堂', en: 'Fengyuan Dining Hall', kind: 'block', x: -235, z: -343, w: 40, d: 24, h: 16,
    desc: '嵌在远见公寓组团内。分楼层设大伙餐厅（G层、1层）、风味餐厅（2层、3层）及零点中餐厅（4层），G层设自营风味饮品及面包业态。', services: ['canteen-menu'] },

  // ---- 中东组团 ----
  { id: 'n-school', name: '北区学部楼', en: 'North Building for Schools', kind: 'block', x: 100, z: -390, w: 130, d: 60, h: 28,
    desc: '分布有纪检监察学院、外国语学院、哲学院、国学院、历史学院、文学院、生态环境学院、教育学院和心理学系办公场地。', services: [] },
  { id: 'gx3', name: '公学三楼', en: 'Teaching Building 3', kind: 'block', x: 92, z: -338, w: 77, d: 22, h: 28,
    desc: '公共教学楼。设32间智慧教室，含240-280人教室1间。', services: ['activity-space'] },
  { id: 'gx2', name: '公学二楼', en: 'Teaching Building 2', kind: 'block', x: 75, z: -275, w: 100, d: 28, h: 26,
    desc: '公共教学楼。设40间智慧教室，含240-280人教室2间。', services: ['activity-space'] },
  { id: 'data', name: '数据中心', en: 'Data Center', kind: 'block', x: 153, z: -274, w: 27, d: 28, h: 20,
    desc: '设信息技术中心办公场地、数据机房和图书馆书库；1层设图书借阅部与图书取还一体机。', services: [] },
  { id: 'theatre', name: '先锋剧场', en: 'Pioneer Theatre', kind: 'landmark', x: 46, z: -188, w: 50, d: 68, h: 22,
    desc: '内设680人多功能剧场、120人实验剧场、各类排练厅、琴房、录音厅等空间。', services: [] },
  { id: 'shimo', name: '石墨书房', en: 'Shimo Reading Room', kind: 'block', x: 92, z: -223, w: 30, d: 22, h: 10,
    desc: '图书馆在建期间开设的阅览空间，满架可藏书约3.2万册，阅览座位可预约使用。', services: ['shimo-room'] },
  { id: 'affairs', name: '学生事务中心', en: 'Student Affairs Center', kind: 'block', x: 156, z: -196, w: 60, d: 40, h: 22,
    desc: '一站式学生事务办理。北侧1层设医务中心，南侧设多功能报告厅、陕公书屋及心理、学业、职业辅导室，B1设就业空间与活动室；明德书院、体育部办公场地亦设于此。', services: ['quiet-pod'] },
  { id: 'shuwu', name: '陕公书屋', en: 'Shangong Bookhouse', kind: 'block', x: 157, z: -166, w: 30, d: 18, h: 8,
    desc: '校园书屋，位于学生事务中心南侧1层。', services: [] },

  // ---- 东区 ----
  { id: 'mgmt', name: '管理学部楼', en: 'Management Building', kind: 'block', x: 247, z: -374, w: 95, d: 50, h: 26,
    desc: '分布有公共管理学院、信息资源管理学院和农业与农村发展学院办公场地。', services: [] },
  { id: 'gx4', name: '公学四楼', en: 'Teaching Building 4', kind: 'block', x: 247, z: -323, w: 55, d: 50, h: 28,
    desc: '公共教学楼。设29间智慧教室，含100-120人教室2间。', services: ['activity-space'] },
  { id: 'jiayuan', name: '嘉园食堂', en: 'Jiayuan Dining Hall', kind: 'block', x: 281, z: -246, w: 55, d: 45, h: 16,
    desc: '东区食堂，设体重友好窗口。秋季学期开放1层风味餐厅，2层提供基本大伙并开设水吧。', services: ['canteen-menu'] },

  // ---- 东南区 ----
  { id: 'ops', name: '校园运行中心', en: 'Campus Operations Center', kind: 'block', x: 452, z: 236, w: 20, d: 80, h: 22,
    desc: '校园运行调度，部分管理服务机构办公场地。', services: [] },
  { id: 'health', name: '健康教育中心（校医院）', en: 'Health Education Center', kind: 'block', x: 500, z: 206, w: 40, d: 45, h: 18,
    desc: '校医院。常态化开设内科、外科、耳鼻喉科、中医科、心理门诊等临床科室，设B超室等辅助检查科室，常见病校内一站式诊疗。', services: ['hospital'] },
];

// 道路：轴对齐矩形，name 取自高德/官方地图
export const ROADS = [
  { name: '宝塔山路', x: -10, z: -302, w: 1020, d: 12 },
  { name: '明德街', x: 0, z: 140, w: 1120, d: 18 },
  { name: '凤栖三路', x: -345, z: 19, w: 18, d: 660 },
  { name: '清源山路', x: -40, z: -81, w: 14, d: 442 },
  { name: '东区联络路', x: 475, z: -80, w: 14, d: 440 },
];

// 校门（出生点候选）：axis = 所跨道路走向，face = 门牌朝向（校外方向）
export const GATES = [
  { name: '西门', en: 'West Gate', x: -559, z: 140, axis: 'x', face: 'w' },
  { name: '西北门', en: 'Northwest Gate', x: -512, z: -310, axis: 'x', face: 'w' },
  { name: '西南门', en: 'Southwest Gate', x: -348, z: 331, axis: 'z', face: 's' },
  { name: '东南门', en: 'Southeast Gate', x: 196, z: 401, axis: 'z', face: 's' },
];

// 水系：现状无天然水面，留空数组保留渲染管线
export const WATER = [];

// 广场 / 硬质铺装
export const PLAZAS = [
  { x: 80, z: -235, w: 90, d: 60 },    // 中央学术轴线（公学二楼—先锋剧场之间）
  { x: -178, z: -360, w: 150, d: 30 }, // 远见公寓围合内院
];

// 服务定义：bookingUrl 为校方现有通道，null 表示占位待接入
export const SERVICES = {
  'canteen-menu': {
    name: '食堂菜品查询', icon: '🍚', bookingUrl: null,
    note: '菜单每周更新；当前为 11月22日（星期日）菜单，来源「RUC小通」公众号。',
  },
  'study-room': {
    name: '学习中心预约（研学工位）', icon: '📖',
    bookingUrl: 'https://yxkj.ruc.edu.cn/jsq-v/?plat=codeTimeTokenInfo&code=00245d1cb83804e89ea42edb91f153cc&state=STATE#/main/book',
    note: '跳转校方现有研学工位预约通道，覆盖求实、远见两个学习中心。',
  },
  'quiet-pod': {
    name: '静音舱预约', icon: '🎧',
    bookingUrl: 'https://jyc.ruc.edu.cn/space/?token=eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiIyMDI2MTAxMzIxIiwiaWF0IjoxNzk1MjQ4NTk1LCJleHAiOjE3OTUyNDg2NTUsInJhbmRvbSI6IlJFaG8ifQ.E8gfJ-LJC9FqNYo-DwePa198jmi92VvxArRktuHGurRGSyAn6l5gMxaVGalZ6oUup1JMlMJIOrE4yA9yKqnGdQ&plat=codeTimeTokenInfo&code=e4112c222e642830451aeeeb42ea86dd&state=STATE',
    note: '跳转校方现有静音舱预约通道；部分教学楼亦设静音舱。',
  },
  'activity-space': {
    name: '学生活动空间预约', icon: '📅',
    bookingUrl: 'https://service.ruc.edu.cn/reservation/fe/site/special/m_special?id=42&platform_id=26',
    note: '跳转校方现有学生活动空间预约通道；部分教学楼设活动空间。',
  },
  'shimo-room': {
    name: '石墨书房（阅览室）预约', icon: '📚',
    bookingUrl: 'https://zwlib.ruc.edu.cn/jsq-v/#/main/index',
    note: '跳转图书馆现有阅览室预约通道。',
  },
  'hospital': {
    name: '医务预约 / 查询', icon: '🏥', bookingUrl: null,
    note: '当前跳转校方现有预约通道。医疗信息以校医院官方发布为准。',
  },
  'gym': {
    name: '健身房预约', icon: '🏋️', bookingUrl: null,
    note: '当前跳转校方现有预约通道；获校方支持后可在本平台直接预约。',
  },
};

// 食堂菜单：11月22日（星期日），来源「RUC小通」公众号周菜单，按食堂建筑 id 分组
// 每行 = 一餐 × 一个大类，菜品以「、」连接；体重友好窗口套盒含配菜与热量
export const CANTEEN_MENU = {
  heyuan: [
    { name: '小米南瓜粥、五黑粥、炒米饭', tag: '早餐 · 米类' },
    { name: '烤冷面、鸭肉卷、酱香饼、金麦流沙包、胡萝卜鸡蛋包、韭菜鸡蛋粉条包、香煎面包片', tag: '早餐 · 中式面类' },
    { name: '海苔肉松蛋糕、枣糕', tag: '早餐 · 西式面类' },
    { name: '糯玉米', tag: '早餐 · 其他谷物及薯类' },
    { name: '白鸡蛋、茶鸡蛋、酥皮馅饼、豆腐脑、白豆浆、纯牛奶', tag: '早餐 · 蛋白质类' },
    { name: '热拌芹菜', tag: '早餐 · 蔬菜类' },
    { name: '清炒快菜、红烧茄子、蒜蓉粉丝娃娃菜、清炒土豆丝', tag: '午餐 · 蔬菜类' },
    { name: '菜心豆腐、土豆烧牛肉', tag: '午餐 · 豆制品类' },
    { name: '豉汁蒸鸡、蒜香鸡、菜花炒肉、酸汤龙利鱼、滑蛋虾仁、剁椒牛肉拌饭、剁椒孜然羊肉拌饭、剁椒可乐翅根拌饭、剁椒卤香鸡腿拌饭、剁椒香辣鱿鱼拌饭', tag: '午餐 · 肉类' },
    { name: '牛肉饼、三麦馒头、馒头、胡萝卜鸡蛋包', tag: '午餐 · 谷物类' },
    { name: '尖椒茄丁、清炒菠菜、蒜蓉西兰花、麻辣豆腐、韭菜绿豆芽、黑椒牛柳、海带炖鸭、青笋鸡片、巴斯克炖鸡、辣子鸡、咖喱鸡块、剁椒牛肉拌饭、剁椒孜然羊肉拌饭、剁椒可乐翅根拌饭、剁椒卤香鸡腿拌饭、剁椒香辣鱿鱼拌饭、三麦馒头、花卷、全麦馒头、馒头', tag: '晚餐' },
  ],
  fengyuan: [
    { name: '南瓜小米粥、蔬菜玉米粥、燕麦红枣花生粥', tag: '早餐 · 粥类' },
    { name: '素炒河粉、蛋炒饭、清扬小馄饨、韭菜鸡蛋包、三丁酱肉包、鲜肉白菜包、鸡蛋饼、葱花大饼、土豆丝煎鸡蛋、豆渣饼、紫薯黑米包、葱花卷、煎饺、玉米饼、紫米馒头、小馒头、烧饼夹土豆丝、肉夹馍、煎面包片、手抓饼、豆沙饼、金麦流沙包、肠子包、炸糕、蛋挞、油条', tag: '早餐 · 中式面类' },
    { name: '蒸红薯、蒸玉米', tag: '早餐 · 其他谷物及薯类' },
    { name: '蒸鸡蛋羹、白鸡蛋、茶鸡蛋、豆浆、豆腐脑、牛奶', tag: '早餐 · 蛋白质类' },
    { name: '清炒蔬菜', tag: '早餐 · 蔬菜类' },
    { name: '韭菜绿豆芽、皮蛋上汤时蔬、黄豆芽炒粉条、蒜蓉黄心菜、尖椒土豆丝、白灼罗马生菜、炝炒圆白菜、小炒有机菜花、鱼香茄子', tag: '午餐 · 蔬菜类' },
    { name: '西红柿炒鸡蛋、剁椒鸡蛋', tag: '午餐 · 鸡蛋类' },
    { name: '葱烧豆腐、三鲜豆腐', tag: '午餐 · 豆制品类' },
    { name: '蚂蚁上树、肉沫榄菜豇豆、糖醋排骨、蒜苔肉丝、豇豆肉丝、珍珠丸子、红烧狮子头、传统锅包肉、剁椒肘子、肉末豆花', tag: '午餐 · 猪肉类' },
    { name: '柠檬干煎鸡、鲜炒藤椒鸡、宫保鸡丁、白切鸡、盐水鸭胗、酱香鸭块', tag: '午餐 · 禽类' },
    { name: '清蒸巴沙鱼、孜然肉丁、骨肉相连、椒盐锅包鱼、葱爆羊肉', tag: '午餐 · 其他类' },
    { name: '酱香饼、花卷、馒头、蒸红薯、蒸玉米、杂粮饭', tag: '午餐 · 主食类' },
    { name: '清炒圆白菜、白灼罗马生菜、清炒莴笋片、香菇油菜、清炒西兰花、上汤娃娃菜、孜然炒馕、醋熘绿豆芽、小炒有机菜花、西红柿炒鸡蛋、香葱炒鸡蛋、精品麻婆豆腐、红烧日本豆腐、香辣肉丝、小酥肉、传统锅包肉、豇豆肉丝、红烧狮子头、水煮肉片、鲍汁红烧肉、肉米蒸蛋、酱香鸡腿、新疆大盘鸡、蒜香鸡翅根、白灼鸡片、蜜汁鸭腿、口水鸡、酸菜鱼片、香炸素什锦、蒜香明太鱼、五香鳕鱼排、豇豆焖面、馒头、蒸玉米、杂粮饭、蒸贝贝南瓜、花卷、黑米面窝头', tag: '晚餐' },
  ],
  jiayuan: [
    { name: '皮蛋蔬菜粥、白米粥、绿豆莲子百合粥、南瓜粥、豆浆', tag: '早餐 · 汤粥类' },
    { name: '黄油面包、小法棍面包、蜂蜜小面包、肉松蛋糕卷、香妃蛋糕卷、雪芙面包、鸡汤馄饨、馅饼、烧麦、手抓饼、黄桥烧饼、板烧鸡腿堡、三明治、葱油饼、扬州炒饭、葡萄干蛋糕卷、流沙包、牛奶餐包、锅贴、牛肉饼、肉松掉渣饼、白油饼、香辣豆腐包、素炒米线、疙瘩汤、素炒河粉、千层肉饼、鲜肉大葱包、西葫芦鸡蛋包、鲜肉白菜包、鲜肉酸菜包、烧饼夹尖椒鸡蛋、紫薯玫瑰烧饼、墨西哥面包、芝士条面包、西葫芦糊塌子、岩烧乳酪包、掉渣饼、肉夹馍、烧饼夹火腿、板烧鸡腿堡、煎鸡排、油条、糖油饼、蛋挞', tag: '早餐 · 中西式面点类' },
    { name: '蒸红薯、蒸玉米、蒸胡萝卜', tag: '早餐 · 其他谷薯根茎类' },
    { name: '白鸡蛋、土豆丝煎鸡蛋、红豆面包、豆腐脑、牛奶', tag: '早餐 · 蛋白质类' },
    { name: '凉拌小菜', tag: '早餐 · 蔬菜类' },
    { name: '清炒圆白菜、白灼罗马生菜、清炒莴笋片、香菇油菜、清炒西兰花、上汤娃娃菜、蒜蓉粉丝金针菇、炝拌藕片、小炒有机菜花', tag: '午餐 · 蔬菜类' },
    { name: '大盘鸡、平菇肉片、回锅肉、豇豆肉丝、糯米狮子头、木耳肉片、豆皮肉卷、红烧排骨、酱香鸡腿、湘西土匪鸭、奥尔良烤翅根、水煮鸡片、玉米鸡丁、糖醋里脊、清蒸狮子头、辣椒烧杭茄、蒜香鸡翅根、宫保鸡丁、骨肉相连、锅包鱼片、外婆炒鸡蛋、京酱肉丝、猪肉炖粉条、汆丸子、烤鸡腿、鸡米花、熘肉段、毛氏红烧肉、焦熘丸子、鱼香肉丝', tag: '午餐 · 肉类' },
    { name: '酸菜鱼片、白灼虾、清蒸巴沙鱼、水煮鱼、香酥鱼排', tag: '午餐 · 水产品类' },
    { name: '西红柿炒鸡蛋、韭菜炒鸡蛋、肉米蒸蛋', tag: '午餐 · 蛋类' },
    { name: '家常豆腐、三鲜烩豆腐、尖椒炒豆皮、油泼豆腐、红烧豆腐', tag: '午餐 · 豆制品类' },
    { name: '鸡蛋大饼、玉米面窝窝头、小馒头、蒸红薯、蒸玉米、杂粮饭', tag: '午餐 · 谷薯类' },
    { name: '橄榄四季豆、西葫芦炒木耳、酸菜豆腐、清炒芹菜、尖椒土豆丝、白灼罗马生菜、炝炒圆白菜、清炒蔬菜、丝瓜烩面筋、小炒黄牛肉、芹菜肉丝、糖醋丸子、京酱肉丝、腐竹炒肉片、传统锅包肉、剁椒肘子、滑溜肉片、酱香鸡腿、鲜炒藤椒鸡、冬笋鸡丝、水煮肉片、盐水鸭胗、酱香鸭块、芥末薯条、鲍汁红烧肉、红烧狮子头、葱爆羊肉、酸菜鱼片、临沂炒鸡、猪肉炖粉条、小炒鸭胗、柠檬鸭块、鸡米花、扒肉条（猪肉）、剁椒肉末鸡蛋、珍珠丸子、蒜香排骨、豇豆炒肉、木耳肉片、西红柿牛腩、清蒸龙利鱼、椒盐虾、口水巴沙鱼、红烧鱼脯、黑椒牛肋条、西红柿炒鸡蛋、蒸鸡蛋羹、黄瓜炒鸡蛋、葱烧豆腐、包浆豆腐、尖椒炒豆皮、家常豆腐、三鲜豆腐、流沙包、小馒头、蒸玉米、杂粮饭、蒸胡萝卜、鸡蛋大饼、红糖提子糕', tag: '晚餐' },
    { name: '口蘑炒牛肉紫米饭套盒（紫米饭／口蘑炒牛肉／清炒荷兰豆·豌豆玉米粒／蒸水蛋）', tag: '体重友好 · 绿档午餐 465kcal' },
    { name: '竹笙蒸鸡柳糙米饭套盒（糙米饭／竹笙蒸鸡柳／蚝油西兰花／白煮蛋）', tag: '体重友好 · 绿档晚餐 390kcal' },
    { name: '酸汤龙利鱼紫米饭套盒（紫米饭／酸汤龙利鱼／彩椒炒西葫芦／丝瓜炒腐竹）', tag: '体重友好 · 黄档午餐 540kcal' },
    { name: '咖喱牛肉糙米饭套盒（糙米饭／咖喱牛肉／清炒西葫芦／烧豆腐）', tag: '体重友好 · 黄档晚餐 465kcal' },
    { name: '少油麻辣香锅杂粮饭套盒（紫米饭／少油麻辣香锅·虾仁鸡胸藕片木／上汤娃娃菜／蒸蛋羹）', tag: '体重友好 · 红档午餐 635kcal' },
    { name: '蘑菇炖鸡糙米饭套盒（糙米饭／蘑菇炖鸡／蒜蓉西兰花／凉拌豆腐）', tag: '体重友好 · 红档晚餐 595kcal' },
  ],
};
