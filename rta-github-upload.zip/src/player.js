import * as THREE from 'three';
import { BOUNDS } from './data/campus.js';

const WALK = 9;      // m/s
const RUN = 34;
const RADIUS = 1.6;

export class Player {
  constructor(scene, domElement, colliders) {
    this.colliders = colliders;
    this.dom = domElement;
    this.keys = new Set();
    this.yaw = 0;   // 初始朝北，自西南门沿凤栖三路入校
    this.pitch = .42;
    this.dist = 26;
    this.dragDist = 0;
    this.stick = { x: 0, y: 0 }; // 虚拟摇杆输入：x=右, y=前进, 模长<=1
    this.enabled = false;

    this.pos = new THREE.Vector3(-345, 0, 315); // 西南门入校，凤栖三路南端
    this.vel = new THREE.Vector3();
    this.facing = Math.PI / 2;

    // ---- 角色：低多边形小人 ----
    const g = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x2b3a55, flatShading: true, roughness: .9 });
    const headMat = new THREE.MeshStandardMaterial({ color: 0xe8c39e, flatShading: true, roughness: .9 });
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(.62, 1.5, 4, 8), bodyMat);
    body.position.y = 1.55; body.castShadow = true;
    const head = new THREE.Mesh(new THREE.SphereGeometry(.46, 12, 10), headMat);
    head.position.y = 2.85; head.castShadow = true;
    // 书包（人大红点缀）
    const pack = new THREE.Mesh(
      new THREE.BoxGeometry(.7, .9, .35),
      new THREE.MeshStandardMaterial({ color: 0x9d2235, flatShading: true, roughness: .9 })
    );
    pack.position.set(0, 1.8, .5);
    g.add(body, head, pack);
    this.mesh = g;
    this.mesh.position.copy(this.pos);
    scene.add(g);

    this.camera = new THREE.PerspectiveCamera(58, 1, .5, 3000);
    this._bind();
  }

  _bind() {
    addEventListener('keydown', e => {
      this.keys.add(e.code);
      if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
    });
    addEventListener('keyup', e => this.keys.delete(e.code));
    addEventListener('blur', () => this.keys.clear());

    let dragging = false, px = 0, py = 0;
    this.dom.addEventListener('pointerdown', e => {
      dragging = true; this.dragDist = 0; px = e.clientX; py = e.clientY;
      this.dom.setPointerCapture(e.pointerId);
    });
    this.dom.addEventListener('pointermove', e => {
      if (!dragging || !this.enabled) return;
      const dx = e.clientX - px, dy = e.clientY - py;
      px = e.clientX; py = e.clientY;
      this.dragDist += Math.abs(dx) + Math.abs(dy);
      this.yaw -= dx * .005;
      this.pitch = THREE.MathUtils.clamp(this.pitch + dy * .004, .12, 1.25);
    });
    const up = e => { dragging = false; };
    this.dom.addEventListener('pointerup', up);
    this.dom.addEventListener('pointercancel', up);
    this.dom.addEventListener('wheel', e => {
      if (!this.enabled) return;
      e.preventDefault();
      this.dist = THREE.MathUtils.clamp(this.dist + e.deltaY * .03, 10, 90);
    }, { passive: false });
  }

  get moving() {
    return this.keys.has('KeyW') || this.keys.has('KeyS') || this.keys.has('KeyA') || this.keys.has('KeyD') ||
      this.keys.has('ArrowUp') || this.keys.has('ArrowDown') || this.keys.has('ArrowLeft') || this.keys.has('ArrowRight');
  }

  update(dt) {
    if (!this.enabled) return;

    const kf = (this.keys.has('KeyW') || this.keys.has('ArrowUp') ? 1 : 0) - (this.keys.has('KeyS') || this.keys.has('ArrowDown') ? 1 : 0);
    const kr = (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0) - (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0);
    const f = kf + this.stick.y;
    const r = kr + this.stick.x;
    const mag = Math.hypot(f, r);

    // 摇杆为模拟量：推得越满越快（满推=奔跑）；键盘保持步行/Shift 奔跑
    const stickMag = Math.min(1, Math.hypot(this.stick.x, this.stick.y));
    const speed = (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight')) ? RUN
      : stickMag > 0 ? WALK + (RUN - WALK) * stickMag : WALK;

    if (mag > .06) {
      // 相机朝向下的前进/右向量
      const sin = Math.sin(this.yaw), cos = Math.cos(this.yaw);
      const fx = -sin, fz = -cos;          // forward
      const rx = cos, rz = -sin;           // right
      let vx = fx * f + rx * r;
      let vz = fz * f + rz * r;
      const len = Math.hypot(vx, vz) || 1;
      vx = (vx / len) * speed; vz = (vz / len) * speed;
      this.vel.set(vx, 0, vz);
      this.facing = Math.atan2(vx, vz);
    } else {
      this.vel.multiplyScalar(Math.pow(.0001, dt)); // 阻尼
    }

    // 分轴碰撞求解：逐轴尝试，命中则保持原坐标（可沿墙滑动）
    let px = this.pos.x, pz = this.pos.z;
    const nx = THREE.MathUtils.clamp(this.pos.x + this.vel.x * dt, BOUNDS.minX + 4, BOUNDS.maxX - 4);
    const nz = THREE.MathUtils.clamp(this.pos.z + this.vel.z * dt, BOUNDS.minZ + 4, BOUNDS.maxZ - 4);
    if (!this._hits(nx, pz)) px = nx;
    if (!this._hits(px, nz)) pz = nz;
    this.pos.x = px;
    this.pos.z = pz;

    this.mesh.position.copy(this.pos);
    // 平滑转向
    let df = this.facing - this.mesh.rotation.y;
    while (df > Math.PI) df -= Math.PI * 2;
    while (df < -Math.PI) df += Math.PI * 2;
    this.mesh.rotation.y += df * Math.min(1, dt * 12);

    this._updateCamera();
  }

  _hits(x, z) {
    return this.colliders.some(c =>
      x > c.minX - RADIUS && x < c.maxX + RADIUS &&
      z > c.minZ - RADIUS && z < c.maxZ + RADIUS);
  }

  _updateCamera() {
    const cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    const ox = Math.sin(this.yaw) * cp * this.dist;
    const oz = Math.cos(this.yaw) * cp * this.dist;
    const oy = sp * this.dist + 2;
    this.camera.position.set(this.pos.x + ox, oy, this.pos.z + oz);
    this.camera.lookAt(this.pos.x, 2.2, this.pos.z);
  }

  resize(w, h) {
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }
}
